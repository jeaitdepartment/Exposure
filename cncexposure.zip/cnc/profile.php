<html>
<head>
<title> Welcome to ClixSys! </title>

<link rel="stylesheet" type="text/css" href="profile.css">
</head>

<body>


<div id="Nmenu">
	
	 

</div>



<div id= "cclogoprofile">
	<img src="images/dn.jpg">
</div>

<div id="clixsys">
<h1> CLIX.SYS </h1>	
</div>

 <iframe src="search.php" style="background:white; 
 width:1300;
 position:relative; 
 top:40; 
 border:0px solid black; 
 height:200%;
 left:-90;
 opacity:;
 margin-bottom:300;
 "></iframe> 






</body>
</html/>