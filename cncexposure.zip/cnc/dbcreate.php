<?php

$host ='localhost';
$user ='root';
$pass ='';
$dbname ='cnc';

$myquery = new mysqli($host,$user,$pass,$dbname) or die($myquery->error);


?>